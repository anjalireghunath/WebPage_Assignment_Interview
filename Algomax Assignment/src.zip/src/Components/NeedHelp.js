import React from 'react'

const NeedHelp = () => {
  return (
    

<div className='NeedMain'>
    <div className='needHead'>
    <h1>Need Help?</h1>
    </div>
    <div>
        <h6>We are here to help you</h6>
    </div>
    <div className='contactbutton'>
        <button className='btn btn-light contactctbtn '>Contact</button>
    </div>
</div>


   
  )
}

export default NeedHelp